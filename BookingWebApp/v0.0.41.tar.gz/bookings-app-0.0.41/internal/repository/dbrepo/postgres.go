package dbrepo

func (m *postgresDBRepo) AllUsers() bool {
	return true
}
